alert("Определение,число или нет");
var x=prompt("x=");
if(parseInt(x)*0==0)
alert("Number!");
else alert("Not a number!");
