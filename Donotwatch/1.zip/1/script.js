alert("Вычисление максимального числа");
var x=prompt("x=");
var y=prompt("y=");
var z=prompt("z=");

x1=x*1;
y1=y*1;
z1=z*1;


	var max;
	max=x1*1;
	if(z1*1>max) max=z1;
	if(y1*1>max) max=y1;
	alert(max);





