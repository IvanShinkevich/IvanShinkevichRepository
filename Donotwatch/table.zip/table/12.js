var elem=document.getElementById("A1");
elem.innerHTML=window.innerWidth+ " ";

var elem=document.getElementById("A2");
elem.innerHTML=window.innerHeight+ " ";

var elem=document.getElementById("A3");
elem.innerHTML=window.location.href + "";

var elem=document.getElementById("A4");
elem.innerHTML=window.location.port+ " ";

var elem=document.getElementById("A5");
elem.innerHTML=window.location.protocol + " ";

var elem=document.getElementById("A6");
elem.innerHTML=window.location.search + " ";

var elem=document.getElementById("A7");
elem.innerHTML=window.location.hash + " ";

var elem=document.getElementById("A8");
elem.innerHTML=window.location.host + " ";

var elem=document.getElementById("A9");
elem.innerHTML=window.navigator.appCodeName + " ";

var elem=document.getElementById("A10");
elem.innerHTML=window.navigator.appName + " ";

var elem=document.getElementById("A11");
elem.innerHTML=window.navigator.coockieEnabled + " ";

var elem=document.getElementById("A12");
elem.innerHTML=window.navigator.onLine+ " ";

var elem=document.getElementById("A13");
elem.innerHTML=window.screen.colorDepth+ " ";

var elem=document.getElementById("A14");
elem.innerHTML=window.screen.width+ " ";

var elem=document.getElementById("A15");
elem.innerHTML=window.screen.height+ " ";

var elem=document.getElementById("A16");
elem.innerHTML=window.history.length+ " ";

