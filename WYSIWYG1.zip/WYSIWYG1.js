function check(){
	var field=MFR.By.Id("status");
	field.focus();
	field.innerText="Text colour: "+document.queryCommandValue('forecolor')+"\n\
	Background colour: "+document.queryCommandValue('backcolor')+"\n\
	Fontname: "+document.queryCommandValue('fontname')+"\n\
	Fontsize: "+document.queryCommandValue('fontsize')+"\n";
	if (document.queryCommandState('bold')==true) {field.innerText+="Bold\n"}
	if (document.queryCommandState('underline')==true) {field.innerText+="Underlined\n"}
	if (document.queryCommandState('italic')==true) {field.innerText+="Italic\n"}
	if (document.queryCommandState('insertorderedlist')==true) {field.innerText+="Numerated list\n"}
	if (document.queryCommandState('insertunorderedlist')==true) {field.innerText+="Dotted list\n"}
	if (document.queryCommandState('inserthorizontalrule')==true) {field.innerText+="Horizontal line\n"}
	if (document.queryCommandState('justifyleft')==true) {field.innerText+="Left-aligned\n"}
	if (document.queryCommandState('justifyright')==true) {field.innerText+="Rigth-aligned\n"}
	if (document.queryCommandState('justifycenter')==true) {field.innerText+="Center-aligned\n"}
}



MFR.By.Id("bold").addEventListener("click",function(){
	{
   document.execCommand( 'bold', null, null ); 
   check();
}
})
MFR.By.Id("italic").addEventListener("click",function(){
	{
   document.execCommand( 'italic', null, null );
   check();
}
})
MFR.By.Id("underline").addEventListener("click",function(){
	{
   document.execCommand( 'underline', null, null );
   check(); 
}
})
MFR.By.Id("fontsize").addEventListener("click",function(){
	{
   document.execCommand( 'fontsize', null, MFR.By.Id("fontsize").value*1 ); 
   check();
}
})
MFR.By.Id("fontname").addEventListener("click",function(){
	{
   document.execCommand( 'fontname', null, MFR.By.Id("fontname").value ); 
   check();
}
})
MFR.By.Id("fontcolor").addEventListener("click",function(){
	{
   document.execCommand( 'forecolor', null, MFR.By.Id("fontcolor").value ); 
   check();
}
})
MFR.By.Id("bgcolor").addEventListener("click",function(){
	{
   document.execCommand( 'backcolor', null, MFR.By.Id("bgcolor").value ); 
   check();
}
})
MFR.By.Id("leftal").addEventListener("click",function(){
	{
   document.execCommand( 'justifyleft', null, MFR.By.Id("leftal").value ); 
   check();
}
})
MFR.By.Id("centralal").addEventListener("click",function(){
	{
   document.execCommand( 'justifycenter', null, MFR.By.Id("centralal").value ); 
   check();
}
})
MFR.By.Id("rigthal").addEventListener("click",function(){
	{
   document.execCommand( 'justifyright', null, MFR.By.Id("rigthal").value ); 
   check();
}
})
MFR.By.Id("numlist").addEventListener("click",function(){
	{
   document.execCommand( 'insertorderedlist', null, MFR.By.Id("numlist").value ); 
   check();
}
})
MFR.By.Id("dotlist").addEventListener("click",function(){
	{
   document.execCommand( 'insertunorderedlist', null, MFR.By.Id("dotlist").value ); 
   check();
}
})
MFR.By.Id("link").addEventListener("click",function(){
	{
   document.execCommand( 'createlink', null, prompt("Enter a url please:")); 
   check();
}
})
MFR.By.Id("unlinks").addEventListener("click",function(){
	{
   document.execCommand( 'unlink', null, null); 
   check();
}
})
MFR.By.Id("horline").addEventListener("click",function(){
	{
   document.execCommand( 'inserthorizontalrule', null, null); 
   check();
}
})

MFR.By.Id("reset").addEventListener("click",function(){
	{
   document.execCommand( 'removeformat', null, null); 
   check();
}
})